# buttermap
Mapping and VCF calling pipeline for butterfly genomes from paired-end reads

## Pipeline steps
1. Read mapping with minimap2
2. BAM file generation with samtools
3. Duplicate marking with sambamba
4. Splitting VCF into regions
5. Variant calling per region with freebayes
6. Merging chromosome VCFs with bcftools

## Dependencies
|Software              | Version used in development |
|----------------------|-----------------------------|
|Python                | 3.11.5                      |
|ruffus                | 2.8.4                       |
|minimap2              | 2.26-r1175                  |
|samtools              | 1.17                        |
|sambamba              | 1.0.1                       |
|freebayes             | v1.3.6                      |
|bcftools              | 1.17                        |


## Input files

Buttermap requires the following input files, which must follow the naming rules below:

|File              | File name                   |
|------------------|-----------------------------|
|Reference FASTA   | {species}.reference.fasta   |
|Reads             | {sample_id}.{n}.fastq.gz    |